package core_java;

import java.util.Arrays;

public class Asc_using_sort_methopd {
	
	public static void main(String args[])
	
	{
		int i;
		int a[]= {90,23,5,109,12,22,67,34};
		
		Arrays.sort(a);
		
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
}
