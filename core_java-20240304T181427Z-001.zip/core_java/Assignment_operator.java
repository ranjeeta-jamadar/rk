package core_java;

public class Assignment_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=10;
		int b=20;
		
		a+=b;// a=a+b
		System.out.println(a);//30
		System.out.println(b);//20
		
		int x=10;
		int y=20;
		y+=x;    
		System.out.println(x);
		System.out.println(y);

	}

}
