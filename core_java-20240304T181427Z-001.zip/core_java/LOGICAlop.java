package core_java;

public class LOGICAlop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=30;
		int b=20;
		System.out.println((a>b)&& (a>10));  //  1   &&    1       true 
		
		
		System.out.println((a<b) || (a==b));//0     ||   0         false
		
		
		
		System.out.println(!(a>b));
	}

}
