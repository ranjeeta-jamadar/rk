package core_java;

public class P_N_Z {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=30;
		if(a>0)
		{
			System.out.println("no is positive");
		}
		else if(a<0)
		{
			System.out.println("no is negative");
		}
		else
		{
			System.out.println("zero");
		}
	}

}
