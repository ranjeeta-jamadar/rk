package core_java;

public class Selection_sort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
