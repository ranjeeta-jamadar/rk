package core_java;

class Staticvar
{
	static int a=100;//static / global
	static int b;
	
	final int d=90;
}

public class Static_variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		final int c=10;
		
	
		Staticvar ob= new Staticvar();
		System.out.println(ob.d);
		
		
		Staticvar.b=200;
		Staticvar.a=20;
		
		System.out.println(Staticvar.a);
		System.out.println(Staticvar.b);
		
	}

}
