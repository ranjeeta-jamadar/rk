package core_java;

import java.util.Scanner;

public class SwitchCase1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a;
		int b;
		int choice;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter a:");
		a=sc.nextInt();
		System.out.println("enter b:");
		b=sc.nextInt();
		System.out.println("enter the choice between 1to 5");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1: System.out.println("addition:"+(a+b));
		break;
		case 2: System.out.println("subtraction:"+(a-b));
		break;
		case 3: System.out.println("multiplication:"+(a*b));
		break;
		case 4: System.out.println("division:"+(a/b));
		break;
		case 5: System.out.println("modulas:"+(a%b));
		break;
		default: System.out.println("invalid choice");
		}
		

	}

}
