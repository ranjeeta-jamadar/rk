package core_java;

public class bitwise_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=5;
		int b=7;
		 System.out.println(a|b);
		 System.out.println(a&b);
		 System.out.println(a^b);
		 System.out.println(~a);

	}

}
