package core_java;

public class bubble_sort {
	
	public static void main(String[] args)
	{
		int i,j,c;
		int a[]= {1,7,5,9,2,12,53,25};
		
		System.out.println("before ascending order");
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
			
		}
		
		
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					c=a[i];
					a[i]=a[j];
					a[j]=c;
				}
			}
		}
		System.out.println("after swapping");
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}

}
