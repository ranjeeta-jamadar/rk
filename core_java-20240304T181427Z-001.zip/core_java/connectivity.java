
package core_java;
import java.sql.*;
public class connectivity {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		String url="jdbc:mysql://localhost:3306/sakshidb";
		String uname="root";
		String pass="Oneplusnord2";
		String query="select username from student where userid=3";
		
       
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con= DriverManager.getConnection(url,uname,pass);
		Statement st= con.createStatement();
		ResultSet rs=st.executeQuery(query);
		rs.next();
		String name=rs.getString("username");
		System.out.println(name);
		
		
		st.close();
		con.close();
		
	}

}
