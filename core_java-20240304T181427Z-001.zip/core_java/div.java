package core_java;

import java.util.Scanner;

public class div {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the num");
		n=sc.nextInt();
		
		if((n%3==0) && (n%5==0))
		{
			System.out.println(" num is div by 3 and 5 both");
			
		}
		else if(n%3==0)
		{
			System.out.println(" num is div by 3");
		}
		else if(n%5==0)
		{
			System.out.println(" num is div b 5");
		}
		else
		{
			System.out.println("it is div by any another number");
		}
	}

}
