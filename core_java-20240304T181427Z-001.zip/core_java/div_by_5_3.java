package core_java;

public class div_by_5_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n=29;
		if((n%3==0)&&(n%5==0))
		{
			System.out.println("num is div by 5 and 3 both");
		}
		else if(n%3==0)
		{
			System.out.println("no is div by 3");
		}
		else if(n%5==0)
		{
			System.out.println("no is div by 5");
		}
		else
		{
			System.out.println("num is not div by 5 and 3 both");
		}
	}

}
