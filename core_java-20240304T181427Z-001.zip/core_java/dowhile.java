package core_java;

public class dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		int i;
//		i=1;
//		do
//		{
//			System.out.println(i);
//			i++;
//		}
//		while(i<=100);
		
		
		
//		int i;
//		
//		i=;
//		do
//		{
//			System.out.println(i);
//		
//			i=i+2;
//		}
//		while(i>=100);
//		
//	}

	
//	int n=5;
//	int i=1;
//	int t=0;
//	do
//	{
//		t=n*i;
//		System.out.println(n+"X"+i+"="+t);
//		i++;
//	}
//	while(i<=10);
//	
//		int n=5;
//		int i=1;
//		int f=1;
//		do
//		{
//			f=f*i;
//		    i++;
//		}
//		while(i<=n);
//		System.out.println("factorial="+f);
		
	
	
	
	int i=1;
	for(i=1;i<=10;i++)
	{
		if(i==5)
		{
			continue;
		}
		else 
		{
			System.out.println(i);
		}
	}
	
	
	
	
	
	
	
	
	
	
	}
	}
	

