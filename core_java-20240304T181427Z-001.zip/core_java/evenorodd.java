package core_java;

import java.util.Scanner;

public class evenorodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter any num");
		n=sc.nextInt();
		
		if(n%2==0)
		{
			System.out.println("even no");
			
		}
		else
		{
			System.out.println("odd no");
			
		}
		

	}

}
