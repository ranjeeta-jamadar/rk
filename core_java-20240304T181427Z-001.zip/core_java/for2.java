package core_java;

public class for2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i;
		int sum=0;
		
//		for(i=1;i<=100;i++)
//		{
//			System.out.println(i);
//		}
		
		
//		for(i=100;i>=0;i--)
//		{
//			System.out.println(i);
//		}
		
//		for(i=1;i<=100;i++)
//		{
//			if(i%2==1)
//			{
//				System.out.println(i);
//			}
//		}
		
		
//		for(i=1;i<=100;i=i+2)
//		{
//			System.out.println(i);
//		}
//		
		
		
		
		
		
//		for(i=1;i<=100;i++)
//		{
//			System.out.println(i);
//			sum=sum+i;
//			
//		}
//		System.out.println("sum ="+sum);
		
//		for(i=1;i<=100;i++)
//		{
//			if(i%2==1)
//			{
//				System.out.println(i);
//				sum=sum+i;
//			}
//		}
//		System.out.println("sum of series="+sum);
		
		
		for(i=1;i<=100;i=i+2)
		{
			System.out.println(i);
			sum=sum+i;
		}
		System.out.println("sum of series="+sum);
		
		
		
		
		
		
		
	}

}
