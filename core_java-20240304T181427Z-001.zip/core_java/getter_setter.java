package core_java;

class get_set
{
	int a;
	int b;
	String c;
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	@Override
	public String toString() {
		return "get_set [a=" + a + ", b=" + b + ", c=" + c + "]";
	}
	
	
}
public class getter_setter {
	
	public static void main(String[] args)
	{
		
		get_set obj=new get_set();
		obj.setA(10);
		obj.setB(700);
		obj.setC("Sakshi");
		System.out.println(obj.getA());
		System.out.println(obj.toString());
	}

	
	
	
}
