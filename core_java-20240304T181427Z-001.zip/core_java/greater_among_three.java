package core_java;

public class greater_among_three {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=100;
		int b=200;
		int c=300;
		
		
//		if(a>b)
//		{
//			if(a>c)
//			{
//				System.out.println("a is greater");
//			}
//		}
//		
//		else if(b>c)
//		{
//				System.out.println("b is greater");
//		}
//		
//		else
//		{
//			System.out.println("c is greater");
//		}
		
		if((a>b)&&(a>c))
		{
			System.out.println("a is greater");
			
		}
		else if((b>a)&&(b>c))
		{
			System.out.println("b is greater");
		}
		
		else 
			
		{
			System.out.println("c is greater");
		}
		
		
	}

}
