package core_java;

public class hello_world {

	public static void main(String[] args) {
		
 
		// this statement is to print something 
	System.out.println("hello world");
	}

}
