package core_java;

public class if1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
//		int a=18;
//		if(a==10)
//		{
//		
//			System.out.println("true");
//		}
//		int x=10;
//		int y=56;
//		if(x>y)
//		{
//			System.out.println("x is greater");
//		}
//		
//		int n=21;
//		if(n%2==1)
//		{
//			System.out.println("num is odd");
//			
//		}
		
		int n=12;
//		int c=n/0;
//		System.out.println(c);
		
		
		
		
		
	}

}
