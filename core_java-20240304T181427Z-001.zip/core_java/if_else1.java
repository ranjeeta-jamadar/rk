package core_java;

public class if_else1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10;
     	if(a==10)
     	{
		
			System.out.println("true");
		}
     	else 
     	{
     		System.out.println("false");
     	}
     	
     	
		int x=100;
		int y=56;
		if(x>y)
		{
			System.out.println("x is greater");
		}
		else
		{
			System.out.println("y is greater");
		}
		
		int n=21;
		if(n%2==1)
		{
			System.out.println("num is odd");
			
		}
		else
		{
			System.out.println("num is even");
		}
		
		
	}

}
