package core_java;

class instance
{
	int a=100; //instance variable
	int b;
}

public class instance_var {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		instance obj = new instance();   // object creation 
		
		obj.a=10;
		obj.b=20;
		
		System.out.println(obj.a);
		System.out.println(obj.b);
		
instance obj1 = new instance();   // object creation 
		
		obj1.a=80;
		obj1.b=90;
		
		System.out.println(obj1.a);
		System.out.println(obj1.b);
		
		
		
	}

}
