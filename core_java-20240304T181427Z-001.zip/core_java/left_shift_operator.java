package core_java;

public class left_shift_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(10>>2);//40
		System.out.println(5>>3);//40
		
		
		
		
		
		
		
		
		
//		System.out.println(20<<2);//80
//		System.out.println(15<<4);//240
		
		
		
	}

}
