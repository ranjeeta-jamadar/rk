package core_java;

class local
{
	int s=100;//instance variable 
	public void func1()
	{
		int a=100;         //local variable 
		int b=200;
		
		System.out.println(a);
		System.out.println(b);
	}
	
	public void func2(int x, String y)
	{
		System.out.println(x);
		System.out.println(y);
	}
}

public class local_variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		local ob = new local();
		ob.func1();
		ob.func2(30, "yash");
		
		
	}

}
