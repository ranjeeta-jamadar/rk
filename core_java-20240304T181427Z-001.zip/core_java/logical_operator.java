package core_java;

public class logical_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
//		System.out.println((5>3) && (8>5));
//		
//		System.out.println((5>3) && (8<5));
//		
//		System.out.println((5>3) || (8>5));
//		
//		System.out.println((5<3) || (8>5));
//		System.out.println((5<3) || (8<5));
//		
//		
//		System.out.println(!(5==3));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
