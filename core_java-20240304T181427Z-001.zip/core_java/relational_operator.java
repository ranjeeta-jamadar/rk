package core_java;

public class relational_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10;
		int b=20;
		
		System.out.println(a==b);//comparison operator
		System.out.println(a!=b);//not equal
		System.out.println(a>b);// greater thn 
		System.out.println(a<b);//less thn 
		System.out.println(a>=b);// greater equal a>b or a==b
		System.out.println(a<=10);// less equal     a<b   or a == b
	}

}
