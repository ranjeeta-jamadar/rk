package core_java;

import java.util.Scanner;

public class report_card {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int english;
		int hindi;
		int maths;
		int sst;
		int science;
		int computer;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the english marks");
		english=sc.nextInt();
		System.out.println("enter the hindi marks");
		hindi=sc.nextInt();
		System.out.println("enter the maths marks");
		maths=sc.nextInt();
		System.out.println("enter the sst marks");
		sst=sc.nextInt();
		System.out.println("enter the science marks");
		science=sc.nextInt();
		System.out.println("enter the computer marks");
		computer=sc.nextInt();
		int total;
		total=english+hindi+maths+sst+science+computer;
		System.out.println("total marks="+total);
		double per;
		per=total/6;
		System.out.println("percentage="+per);
		
	}

}
