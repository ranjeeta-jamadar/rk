package core_java;

import java.util.Scanner;

public class reportcard {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int english;
		int hindi;
		int science;
		int sst;
		int maths;
		int computer;
		
		Scanner sc=new Scanner(System.in);// taking input from user
		
		System.out.println("enter the marks of english");
		english=sc.nextInt();
		
		System.out.println("enter the marks of hindi");
		hindi= sc.nextInt();
		
		System.out.println("enter the marks of science");
		science= sc.nextInt();
		
		System.out.println("enter the marks of sst");
		sst= sc.nextInt();
		
		System.out.println("enter the marks of maths");
		maths= sc.nextInt();
		
		
		System.out.println("enter the marks of computer");
		computer= sc.nextInt();
		
		int total;
		total=english+hindi+science+sst+maths+computer;
		
		System.out.println("total marks="+total);
		
		double per;
		per=total/6;
		
		System.out.println("percentage of student="+per);
		
	}

}
