package core_java;

import java.util.Arrays;
import java.util.Collections;

public class reverse_an_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**gjgghjkhkhkljk
		jhgjkhk
		jfygik
		khgvkkk*/
		
	/*	int i;
		int a[]= {90,23,5,109,12,22,67,34};
		
		Arrays.sort(a);
		for(i=a.length-1;i>=0;i--)
		{
			System.out.println(a[i]);
		}*/

	}

}
