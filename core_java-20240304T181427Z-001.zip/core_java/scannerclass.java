package core_java;

import java.util.Scanner;

public class scannerclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a;
		String b;
		float c;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter a:");
		a=sc.nextInt();
		System.out.println("enter b:");
		b=sc.next();
		System.out.println("enter c:");
		c=sc.nextFloat();
		
		System.out.println("a="+a+"b="+b+"c="+c);
		
		
		
	}

}
