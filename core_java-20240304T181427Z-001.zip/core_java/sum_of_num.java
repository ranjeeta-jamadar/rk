package core_java;

public class sum_of_num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int a=100;
		int b=200;
		int c;
		c=a+b;
		System.out.println("sum of two numbers a and b="+c);
		
		
		
		//area of rectangle 
		double  l=12.2;
		int br=8;
		double area;
		area= l*br;
		System.out.println("area of rectangle is :"+area);
		
		//area of circle 
		int r=4;
		double p=3.14;
		double area2;
		area2= p*r*r;
		System.out.println("Area of circle is :"+area2);
		
		
		
	}

}



