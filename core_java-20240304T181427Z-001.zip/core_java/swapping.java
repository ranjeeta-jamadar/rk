package core_java;

public class swapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int a=10;
		int b=20;
		//int c;
		 System.out.println("before swapping ");
		 System.out.println("a="+a);//10
		 System.out.println("b="+b);//20
		 
//		 c=a;
//		 a=b;
//		 b=c;
		 
//		 a=a+b;
//		 b=a-b;
//		 a=a-b;
		 
		 a=a*b;
		 b=a/b;
		 a=a/b;
		 
		
		 
		 System.out.println("after swapping ");
		// System.out.println("a="+a+"\n"+"b="+b);
		System.out.println("value of a="+a+"\n"+"value of b="+b);
	}

}
