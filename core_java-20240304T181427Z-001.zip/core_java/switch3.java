package core_java;

import java.util.Scanner;

public class switch3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a;
		int b;
		String ch;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of a:");
		a=sc.nextInt();
		System.out.println("enter the value of b:");
		b=sc.nextInt();
		System.out.println("enter your choice");
		ch =sc.next();
		switch(ch)
		{
		case "add": System.out.println("addition is:"+(a+b));
		break;
		
		case "subt": System.out.println("subtraction is:"+(a-b));
		break;
		
		case "mul": System.out.println("multiplication is:"+(a*b));
		break;
		
		case "div": System.out.println("division is:"+(a/b));
		break;
		
		case "mod": System.out.println("modulas is:"+(a%b));
		break;
		
		default: System.out.println("invalid choice");
		}
	}

}
