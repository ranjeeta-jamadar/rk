package core_java;

public class ternary_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10;
		int b=20;
		int r;
		
		
		r=(a>b)?a:b;//r= (10>20)?10:20
		System.out.println(r);
		
		
	}

}
