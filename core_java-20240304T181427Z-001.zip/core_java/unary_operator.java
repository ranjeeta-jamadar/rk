package core_java;

public class unary_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x=10;
		int y=10;
		
		x++;
		++y;
		System.out.println(x);//11
		System.out.println(y);//11
		x--;
		--y;
		System.out.println(x);//10
		System.out.println(y);//10
		int a=10;
		int b=10;
		System.out.println(a++);//10
		System.out.println(a);//11
		System.out.println(++b);//11
		System.out.println(b);//11

	}

}
