package core_java;

public class variables {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int a=10;             //instance variable 
		int b=20;
		
		System.out.println(a);
		System.out.println(b);
		
		
		
		
	}

}
