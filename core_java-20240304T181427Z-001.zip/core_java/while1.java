package core_java;

import java.util.Scanner;

public class while1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i;
//		i=1;
//		while(i<=100)
//		{
//			System.out.println(i);
//			i++;
//		}
		
		
		
//		i=100;
//		while(i>=1)
//		{
//			System.out.println(i);
//			i--;
//		}
//		
		
//		
//		i=1;
//		while(i<=100)
//		{
//			if(i%2==0)
//			{
//				System.out.println(i);
//			}
//			i++;
//		}
		
		
//	S	i=1;
//		while(i<=100)
//		{
//			if(i%2==1)
//			{
//				System.out.println(i);
//			}
//		i++;
//		}
//	}
		
//	i=1;// even 
//	while(i<=100)
//	{
//		System.out.println(i);
//		i=i+2;
//	}
	
//		int sum=0;
//		i=1;
//		while(i<=100)
//		{
//			System.out.println(i);
//			sum=sum+i;
//			i++;
//		}
//		System.out.println("sum of series="+sum);
		
		
//	      i=1;
//	      int sum;
//		while(i<=100)
//		{
//			sum=sum+i;
//			System.out.println(i);
//			i=i+2;
//		
//		}
//		System.out.println("sum="+sum);
		

//		int n;
//		int t=1;
//		Scanner sc=new Scanner(System.in);
//		System.out.println("enter any no");
//		n=sc.nextInt();
//		i=0;
//		while(i<=10)
//		{
//			t=n*i;
//			System.out.println(n+"x"+i+"="+t);
//			i++;
//		}
		
		
//		int n;
//		int f=1;
//		Scanner sc=new Scanner(System.in);
//		System.out.println("enter any no");
//		n=sc.nextInt();
//		i=1;
//		while(i<=n)
//		{
//			f=f*i;
//			i++;
//			
//		}
//		System.out.println("factorial ="+f);
		
	
		
//		while(true)
//		{
//			System.out.println("sakshi");
//		}
		
		
		i=1;
		while(i>100)
		{
			System.out.println(i);
			i++;
		}
//		
		
		
		
		
	
	
	}	
	
}
	
	
	
	
	
	


